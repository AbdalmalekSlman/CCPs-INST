var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/password-reset-requests/reset/route.js")
R.c("server/chunks/[root-of-the-server]__1e03lqmcyo01i._.js")
R.c("server/chunks/_0cr2-bvt66rza._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7vv2xad._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_068as-t69o_qu._.js")
R.c("server/chunks/1oeh_server_app_api_admin_password-reset-requests_reset_route_actions_0_g17otb0sq2s.js")
R.m(82284)
module.exports=R.m(82284).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/password-reset-requests/route.js")
R.c("server/chunks/[root-of-the-server]__1u0sq3a0wfvqa._.js")
R.c("server/chunks/_1m28nkbty5zf8._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7vv2xad._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_068as-t69o_qu._.js")
R.c("server/chunks/1oeh_server_app_api_admin_password-reset-requests_route_actions_0t66d_dsob9by.js")
R.m(48635)
module.exports=R.m(48635).exports

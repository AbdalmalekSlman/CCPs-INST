var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/change-password/route.js")
R.c("server/chunks/[root-of-the-server]__1u0sq3a0wfvqa._.js")
R.c("server/chunks/_1kuapws7-ak5h._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7vv2xad._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_068as-t69o_qu._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_change-password_route_actions_0dcnj10syeqr0.js")
R.m(58986)
module.exports=R.m(58986).exports

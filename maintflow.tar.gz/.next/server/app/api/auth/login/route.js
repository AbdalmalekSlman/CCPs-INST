var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__1z6m5bet3tq_4._.js")
R.c("server/chunks/_0e7f3fqjs4fe8._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7vv2xad._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_068as-t69o_qu._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_1ox7zi0683rx3.js")
R.m(74378)
module.exports=R.m(74378).exports

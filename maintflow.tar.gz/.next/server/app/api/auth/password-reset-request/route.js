var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/password-reset-request/route.js")
R.c("server/chunks/[root-of-the-server]__1z6m5bet3tq_4._.js")
R.c("server/chunks/_14a3qnthg6iac._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7vv2xad._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/1oeh_server_app_api_auth_password-reset-request_route_actions_14yqzo5-onsb_.js")
R.m(52844)
module.exports=R.m(52844).exports

var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/users/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/_1dy8tvx5pw124._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7vv2xad._.js")
R.c("server/chunks/_068as-t69o_qu._.js")
R.c("server/chunks/_next-internal_server_app_api_users_route_actions_0mvbx1f3o0s6x.js")
R.m(72797)
module.exports=R.m(72797).exports

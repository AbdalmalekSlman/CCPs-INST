:HL["/_next/static/chunks/1_w-fxkuqqcs7.css","style"]
:HL["/_next/static/media/07a39a8a4660cc7c-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/605ce01b664af129-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
3:[["children",{"s":"__PAGE__","h":49314}]]
2:[["children",{"s":"inventory","h":49254,"c":"$Q3"}]]
1:[["children",{"s":"dashboard","h":49258,"c":"$Q2"}]]
0:{"b":"k-NdmL_AOJKjbo6K5J7Ga","t":{"t":{"s":"","h":49242,"c":"$Q1"}}}

1:"$Sreact.fragment"
2:"/_next/static/chunks/0wj0noag-9_fs.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
c:"LoadingBoundaryProvider"
d:I[39756,["$2"],"$c"]
15:"ViewportBoundary"
16:I[97367,["$2"],"$15"]
17:"MetadataBoundary"
18:I[97367,["$2"],"$17"]
19:"$Sreact.suspense"
1a:I[27201,["$2"],"IconMark"]
:HL["/_next/static/chunks/1_w-fxkuqqcs7.css","style"]
6:X
6:C
7:X
7:300
7:C
a:X
a:C
12:[["children",{"s":"__PAGE__","h":49314,"d":{"r":"$L13","p":"$@14","v":"$a","s":"$7"}}]]
b:[["children",{"s":"preventive-maintenance","h":49254,"d":{"r":["$","$Ld",null,{"loading":[["$","div","l",{"className":"p-6 space-y-6 animate-pulse max-w-7xl mx-auto","children":[["$","div",null,{"className":"flex justify-between items-center","children":[["$","div",null,{"className":"space-y-2","children":[["$","div",null,{"className":"h-7 bg-neutral-200 rounded-md w-48"}],["$","div",null,{"className":"h-4 bg-neutral-100 rounded-md w-72"}]]}],["$","div",null,{"className":"h-10 bg-neutral-200 rounded-lg w-32"}]]}],["$","div",null,{"className":"flex gap-2 border-b border-neutral-200 pb-3","children":[["$","div",null,{"className":"h-9 bg-neutral-200 rounded-lg w-24"}],["$","div",null,{"className":"h-9 bg-neutral-100 rounded-lg w-24"}],["$","div",null,{"className":"h-9 bg-neutral-100 rounded-lg w-24"}]]}],["$","div",null,{"className":"bg-white rounded-xl border border-neutral-200 shadow-sm overflow-hidden","children":[["$","div",null,{"className":"p-4 border-b border-neutral-100 bg-neutral-50/50 flex gap-4","children":[["$","div",null,{"className":"h-4 bg-neutral-200 rounded w-1/4"}],["$","div",null,{"className":"h-4 bg-neutral-200 rounded w-1/4"}],["$","div",null,{"className":"h-4 bg-neutral-200 rounded w-1/4"}],["$","div",null,{"className":"h-4 bg-neutral-200 rounded w-1/4"}]]}],["$","div",null,{"className":"divide-y divide-neutral-100","children":[["$","div","0",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]]}],["$","div","1",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]]}],["$","div","2",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]]}],["$","div","3",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],"$Le"]}],"$Lf"]}]]}]]}],[],null],"children":"$L10"}],"p":"$@11","v":"$a","s":"$7"},"c":"$Q12"}]]
8:[["children",{"s":"dashboard","h":49258,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}],"p":"$@9","v":"$a","s":"$7"},"c":"$Qb"}]]
1c:X
1c:C
1f:X
1f:C
0:{"t":{"t":{"s":"","h":49242,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1_w-fxkuqqcs7.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/0wj0noag-9_fs.js","async":true}]],["$","html",null,{"lang":"en","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]}]}]]}],"p":"$@5","v":"$6","s":"$7"},"c":"$Q8"},"h":{"r":["$","$1","h",{"children":[null,["$","$L16",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L18",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$19",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"MaintFlow"}],["$","meta","1",{"name":"description","content":"Manage maintenance work orders, equipment, and spare parts."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L1a","3",{}]]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":"$@1b","v":"$1c","s":"$7"}},"a":"$@1d","u":"$@1e","b":"k-NdmL_AOJKjbo6K5J7Ga","r":"$1f"}
20:"/_next/static/chunks/1r9o8npvkp19k.js"
21:I[44561,["$2","$20"],"default"]
22:I[47257,["$2"],"ClientPageRoot"]
23:"/_next/static/chunks/1r57wwg_tzfm7.js"
24:"/_next/static/chunks/213fs8q7n_wb8.js"
25:I[55814,["$2","$23","$24"],"default"]
26:I[97367,["$2"],"OutletBoundary"]
e:["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]
f:["$","div","4",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]]}]
10:["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$21","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/1r9o8npvkp19k.js","async":true}]],"template":["$","$L4",null,{}]}]]}]
13:["$","$1","c",{"children":[["$","$L22",null,{"Component":"$25","serverProvidedParams":null}],[["$","script","script-0",{"src":"/_next/static/chunks/1r57wwg_tzfm7.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/213fs8q7n_wb8.js","async":true}]],["$","$L26",null,{"children":["$","$19",null,{"name":"Next.MetadataOutlet","children":"$@27"}]}]]}]
1e:false
27:null
1d:null
11:"$undefined"
9:"$undefined"
5:"$undefined"
1b:"$undefined"
14:"$undefined"

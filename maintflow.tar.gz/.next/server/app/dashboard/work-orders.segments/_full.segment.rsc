1:"$Sreact.fragment"
2:"/_next/static/chunks/0wj0noag-9_fs.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
9:"LoadingBoundaryProvider"
a:I[39756,["$2"],"$9"]
10:"ViewportBoundary"
11:I[97367,["$2"],"$10"]
13:"MetadataBoundary"
14:I[97367,["$2"],"$13"]
15:"$Sreact.suspense"
18:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/1_w-fxkuqqcs7.css","style"]
:HL["/_next/static/media/07a39a8a4660cc7c-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/605ce01b664af129-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
5:X
7:X
e:[["children",{"s":"__PAGE__","h":514,"d":{"r":"$Lf","p":true,"v":"$7"}}]]
8:[["children",{"s":"work-orders","h":518,"d":{"r":["$","$La",null,{"loading":[["$","div","l",{"className":"p-6 space-y-6 animate-pulse max-w-7xl mx-auto","children":[["$","div",null,{"className":"flex justify-between items-center","children":[["$","div",null,{"className":"space-y-2","children":[["$","div",null,{"className":"h-7 bg-neutral-200 rounded-md w-48"}],["$","div",null,{"className":"h-4 bg-neutral-100 rounded-md w-72"}]]}],["$","div",null,{"className":"h-10 bg-neutral-200 rounded-lg w-32"}]]}],["$","div",null,{"className":"flex gap-2 border-b border-neutral-200 pb-3","children":[["$","div",null,{"className":"h-9 bg-neutral-200 rounded-lg w-24"}],["$","div",null,{"className":"h-9 bg-neutral-100 rounded-lg w-24"}],["$","div",null,{"className":"h-9 bg-neutral-100 rounded-lg w-24"}]]}],["$","div",null,{"className":"bg-white rounded-xl border border-neutral-200 shadow-sm overflow-hidden","children":[["$","div",null,{"className":"p-4 border-b border-neutral-100 bg-neutral-50/50 flex gap-4","children":[["$","div",null,{"className":"h-4 bg-neutral-200 rounded w-1/4"}],["$","div",null,{"className":"h-4 bg-neutral-200 rounded w-1/4"}],["$","div",null,{"className":"h-4 bg-neutral-200 rounded w-1/4"}],["$","div",null,{"className":"h-4 bg-neutral-200 rounded w-1/4"}]]}],["$","div",null,{"className":"divide-y divide-neutral-100","children":[["$","div","0",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]]}],["$","div","1",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]]}],["$","div","2",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]]}],"$Lb","$Lc"]}]]}]]}],[],null],"children":"$Ld"}],"p":true,"v":"$7"},"c":"$Qe"}]]
6:[["children",{"s":"dashboard","h":522,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$7"},"c":"$Q8"}]]
17:X
19:X
1a:X
0:{"P":null,"c":["","dashboard","work-orders"],"q":"","i":false,"t":{"t":{"s":"","h":538,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1_w-fxkuqqcs7.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0wj0noag-9_fs.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L11",null,{"children":"$L12"}],["$","$L14",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$15",null,{"name":"Next.Metadata","children":"$L16"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$17"}},"m":"$undefined","G":["$18",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1_w-fxkuqqcs7.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$19","s":"$1a","a":"$@1b","l":"$undefined","p":"$undefined","d":"$undefined","b":"k-NdmL_AOJKjbo6K5J7Ga","u":"$@1c"}
1d:"/_next/static/chunks/2rkjnmyax_0_m.js"
1e:I[11432,["$2","$1d"],"default"]
1f:I[47257,["$2"],"ClientPageRoot"]
20:"/_next/static/chunks/2pu1fr8bonu44.js"
21:"/_next/static/chunks/213fs8q7n_wb8.js"
22:I[62690,["$2","$20","$21"],"default"]
23:I[97367,["$2"],"OutletBoundary"]
7:C
b:["$","div","3",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]]}]
c:["$","div","4",{"className":"p-4 flex items-center gap-4","children":[["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}],["$","div",null,{"className":"h-5 bg-neutral-100 rounded w-1/4"}]]}]
d:["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$1e","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/2rkjnmyax_0_m.js","async":true,"nonce":"$undefined"}]],"template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
f:["$","$1","c",{"children":[["$","$L1f",null,{"Component":"$22","serverProvidedParams":null}],[["$","script","script-0",{"src":"/_next/static/chunks/2pu1fr8bonu44.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/213fs8q7n_wb8.js","async":true,"nonce":"$undefined"}]],["$","$L23",null,{"children":["$","$15",null,{"name":"Next.MetadataOutlet","children":"$@24"}]}]]}]
1a:300
12:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
25:I[27201,["$2"],"IconMark"]
16:[["$","title","0",{"children":"MaintFlow"}],["$","meta","1",{"name":"description","content":"Manage maintenance work orders, equipment, and spare parts."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L25","3",{}]]
24:null
1a:C
17:C
19:C
5:C
1c:false
1b:null

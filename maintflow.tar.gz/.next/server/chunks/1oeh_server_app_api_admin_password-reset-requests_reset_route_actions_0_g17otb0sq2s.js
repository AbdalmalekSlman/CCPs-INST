module.exports=[19733,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_admin_password-reset-requests_reset_route_actions_0_g17otb0sq2s.js.map
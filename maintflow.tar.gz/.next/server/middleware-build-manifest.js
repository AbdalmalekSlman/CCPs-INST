globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/k-NdmL_AOJKjbo6K5J7Ga/_buildManifest.js",
    "static/k-NdmL_AOJKjbo6K5J7Ga/_ssgManifest.js",
    "static/k-NdmL_AOJKjbo6K5J7Ga/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/3k985_5rc7icn.js",
    "static/chunks/2raug6enbxh70.js",
    "static/chunks/0eq2qk_4dpflg.js",
    "static/chunks/085_ss_6fo-bx.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/account/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/analytics/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/equipment/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/inventory/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/password-reset-requests/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/preventive-maintenance/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/users/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/work-orders/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/work-orders/[id]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/forgot-password/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3k985_5rc7icn.js",
        "static/chunks/2raug6enbxh70.js",
        "static/chunks/0eq2qk_4dpflg.js",
        "static/chunks/085_ss_6fo-bx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
